from django.shortcuts import render
from servicios.models import Servicio
from blog.models import Post
# Create your views here.
def servicios(request):
    servicio = Servicio.objects.all()
    return render(request, 'servicios/servicio.html', {'servicios':servicio})
