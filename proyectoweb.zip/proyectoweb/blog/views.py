from django.shortcuts import render
from blog.models import Post, Categorias

# Create your views here.
def blog(request):
    post = Post.objects.all()
    return render(request, 'blog/blog.html', {'post':post})

def categoria(request, categoria_id):
    categoria = Categorias.objects.get(id=categoria_id)
    post = Post.objects.filter(categoria=categoria)
    return render(request, 'blog/categorias.html', {'categoria':categoria, 'post':post})
